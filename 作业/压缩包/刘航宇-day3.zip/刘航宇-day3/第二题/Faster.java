import java.util.Scanner;

public class Faster {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("输入一个数字n，表示到公司的距离:");
        int n = in.nextInt();
        double bicycle = 27 + 23 + (n / 3.0);
        double walking = n / 1.2;
        if (bicycle < walking)
        {
            System.out.printf("骑着");
        } 
        if (bicycle > walking)
        {
            System.out.printf("走路");
        }
        if (bicycle == walking)
        {
            System.out.printf("一样快");
        }

        in.close();
    }

    
}
