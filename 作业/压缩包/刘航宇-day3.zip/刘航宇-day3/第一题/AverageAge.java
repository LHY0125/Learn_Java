import java.util.Scanner;

public class AverageAge {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("请输入人数");
        int n = in.nextInt();
        double sum = 0;
        int age = 0;
        for (int i = 0; i < n; i++) {
            System.out.print("请输入第" + (i + 1) + "个人的年龄:");
            age = in.nextInt();
            sum += age;
        }
        double average = sum / n;
        System.out.printf("平均年龄为:" + "%.2f", average);
        in.close();
    }
}
