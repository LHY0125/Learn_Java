import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int n = in.nextInt();
        System.out.println(n % 3 == 0 ? "hua" : "ming");
        in.close();
    }
}